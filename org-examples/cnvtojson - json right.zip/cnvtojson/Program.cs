﻿using System;
using System.IO;
using Newtonsoft.Json;

struct patternData
{
    public int name;
    public int dataLen;
    public int byteLen;
    public string dataStr;
};

namespace BinaryPatternDetectApp
{
    class Program
    {
        public static int sampleNum;
        public static int MaxSampleNum = 10000;
        public static string[] sampleFileName;

        public static int MaxbinFileNum = 1000;
        static void Main(string[] args)
        {
            Console.WriteLine("-------------Creating json file...-------------");
            string sampleDirectoryName = @"..\..\..\Samples\";
            string jsonFilename = @"..\..\..\sample.json";
            createJsonFile(sampleDirectoryName, jsonFilename);
        }
        private static void createJsonFile(string sampleDirectoryName, string jsonFilename)
        {
            //read pattern data
            int i, j, n;  
            string[] lines, temp;
            patternData[] pData;
            if (Directory.Exists(sampleDirectoryName))
            {
                sampleNum = 0;
                sampleFileName = new string[MaxSampleNum];
                ProcessDirectory(sampleDirectoryName);
            }
            else
            {
                Console.WriteLine("Sample files no existance");
                return;
            }

            if(sampleNum==0)
            {
                Console.WriteLine("Sample files no existance");
                return;
            }
            
            n = 0;
            for (i = 0; i < sampleNum; i++)
            {
                lines = System.IO.File.ReadAllLines(sampleFileName[i]);
                for (j = 1; j <= 3; j++)
                {
                    if (lines[j].Length < 10) continue;
                    n++;
                }
            }

            pData = new patternData[n];
            n = 0;
            for (i = 0; i < sampleNum; i++)
            {
                lines = System.IO.File.ReadAllLines(sampleFileName[i]);
                for (j = 1; j <= 3; j++)
                {
                    if (lines[j].Length < 10) continue;
                    temp = lines[j].Split(';');                   
                    pData[n].name = Convert.ToInt32(temp[0]);
                    pData[n].dataStr = temp[2];
                    temp = temp[2].Split(' ');
                    pData[n].dataLen = temp.Length;
                    pData[n].byteLen = temp[0].Length/2;                    
                    n++;
                }
            }

            string JSONresult = JsonConvert.SerializeObject(pData);
            using (var tw = new StreamWriter(jsonFilename, true))
            {
                tw.WriteLine(JSONresult.ToString());
                tw.Close();
            }
            Console.WriteLine("Created json file in "+ jsonFilename);            
        }
        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }
        public static void ProcessFile(string path)
        {
            int len = path.Length;
            if (path.Substring(len - 4) == ".csv")
            {
                sampleFileName[sampleNum] = path;
                sampleNum++;
            }
        }
    }
}
