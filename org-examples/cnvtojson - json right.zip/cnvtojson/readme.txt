----How to run----
1. Put binary file *.bin for detecting in binaryfiles folder of project directory.
2. Rename it to 'Data.bin'.
3. Put standard pattern files(.csv) in Examples folder of project directory.
   ex. "(project directory)/Examples/1/Data1.csv"
4. Open project solution file(BinaryPatternDetectApp.sln).
5. Run project.

----Result------
1. Pattern comparing with .csv pattern file.
  Pattern data No: difference, position
2. output result
  Name, Position, Length 
 