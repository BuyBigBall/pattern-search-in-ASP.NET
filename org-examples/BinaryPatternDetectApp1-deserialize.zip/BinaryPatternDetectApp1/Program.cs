﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

struct patternData
{
    public string name;
    public int byteLen;
    public List<int> data;
};

namespace BinaryPatternDetectApp
{
    class Program
    {
        public static int MaxSampleNum = 10000;

        public static int binFileNum;
        public static int MaxbinFileNum = 1000;
        public static string[] binFileName;
        static void Main(string[] args)
        {
            Console.WriteLine("-------------starting...-------------");
            string jsonFileName = @"..\..\..\sample.json";
            string binaryDirectoryName = @"..\..\..\binaryfiles";           
            detectBinaryPattern(jsonFileName, binaryDirectoryName);
        }
        private static void detectBinaryPattern(string jsonFileName, string binaryDirectoryName)
        {
            //read pattern data
            int i, j, k, n, patternNum;
            double[] MinDis;
            int[] MinPos;
            List<patternData> pData;
            HashSet<string> pNames;

            patternNum = 0;
            if (File.Exists(jsonFileName))
            {
                StreamReader r = new StreamReader(jsonFileName);
                string jsonString = r.ReadToEnd();
                pData = JsonConvert.DeserializeObject<List<patternData>>(jsonString);
                patternNum = pData.Count;                
            }
            else
            {
                Console.WriteLine("Json files no existance");
                return;
            }
            if(patternNum ==0)
            {
                Console.WriteLine("patterns no existance");
                return;
            }
            if (Directory.Exists(binaryDirectoryName))
            {
                binFileNum = 0;
                binFileName = new string[MaxbinFileNum];
                ProcessDirectory(binaryDirectoryName);
            }
            else
            {
                Console.WriteLine("binary files no existance");
                return;
            }

            if(binFileNum==0)
            {
                Console.WriteLine("binary files no existance");
                return;
            }

            pNames = new HashSet<string>();

            foreach (var idata in pData)
            {
                pNames.Add(idata.name);
            }

            int bCount;
            MinDis = new double[patternNum];
            MinPos = new int[patternNum];
            for (bCount=0; bCount<binFileNum; bCount++)
            {
                byte[] buffer;
                int bufLen;
                using (BinaryReader br = new BinaryReader(File.Open(binFileName[bCount], FileMode.Open)))
                {
                    bufLen = (int)br.BaseStream.Length;
                    buffer = br.ReadBytes(bufLen);
                }

                if (bufLen < 2) continue;
                Console.WriteLine("");
                Console.WriteLine("Binary file No "+ (bCount+1) +": --------" + binFileName[bCount] + "--------");
                Console.WriteLine("");
                //copmare patterns
                int bufVal, minPos;
                double dis, minDis;
                //double d1, d2, d12;
                //double ck = 0.00001;
                n = 0;
                foreach (var idata in pData)
                {
                    minDis = 0; minPos = 0;
                    int dataLen = idata.data.Count;
                    //if(idata.name)
                    for (i = 0; i < bufLen - dataLen * idata.byteLen + 1 - idata.byteLen; i += idata.byteLen)
                    {
                        dis = 0;
                        //d1 = d2 = d12 = 0;
                        for (j = 0; j < dataLen; j++)
                        {
                            k = i + j * idata.byteLen;
                            if (idata.byteLen > 1)
                            {
                                bufVal = buffer[k] * 256 + buffer[k + 1];
                            }
                            else
                            {
                                bufVal = buffer[k];
                            }
                            if (bufVal != idata.data[j]) dis++;
                        }
                        dis /= dataLen;
                        if (i == 0)
                        {
                            minDis = dis;
                            minPos = i;
                        }
                        else
                        {
                            if (dis < minDis)
                            {
                                minDis = dis;
                                minPos = i;
                            }
                        }
                    }
                    MinDis[n] = minDis;
                    MinPos[n] = minPos;
                    Console.WriteLine("    Pattern No "+ (n+1) + ": " + minDis + ", " + minPos.ToString("X3"));
                    n++;
                }
                //detect binary pattern with name
                int mLen;
                minDis = 0;
                minPos = 0;
                mLen = 0;
                n = 0;
                foreach (var pName in pNames)
                {
                    i = 0;
                    foreach (var idata in pData)
                    {
                        if (idata.name == pName)
                        {
                            if (i == 0)
                            {
                                minDis = MinDis[n];
                                minPos = MinPos[n];
                                mLen = idata.data.Count;
                            }
                            else
                            {
                                if (MinDis[n] < minDis)
                                {
                                    minDis = MinDis[n];
                                    minPos = MinPos[n];
                                    mLen = idata.data.Count;
                                }
                            }
                            i++;
                        }
                    }
                    Console.WriteLine("Name: " + pName + ", Position: " + minPos.ToString("X3") + ", Length: " + mLen);
                    n++;
                }
            }
            Console.WriteLine("----------end------------");            
        }
        public static void ProcessDirectory(string targetDirectory)
        {

            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }
        public static void ProcessFile(string path)
        {
            int len = path.Length;
            
            if (path.Substring(len - 4) == ".bin")
            {
                binFileName[binFileNum] = path;
                binFileNum++;
            }
        }
    }
}
